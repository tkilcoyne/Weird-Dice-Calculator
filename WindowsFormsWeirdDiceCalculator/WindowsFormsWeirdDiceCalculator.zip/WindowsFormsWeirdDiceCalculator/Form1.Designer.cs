﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.oneDie1 = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.twoDie1 = new System.Windows.Forms.Button();
            this.threeDie1 = new System.Windows.Forms.Button();
            this.fourDie1 = new System.Windows.Forms.Button();
            this.oneDie2 = new System.Windows.Forms.Button();
            this.threeDie2 = new System.Windows.Forms.Button();
            this.fourDie2 = new System.Windows.Forms.Button();
            this.fiveDie2 = new System.Windows.Forms.Button();
            this.sixDie2 = new System.Windows.Forms.Button();
            this.eightDie2 = new System.Windows.Forms.Button();
            this.goButton = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox1.Location = new System.Drawing.Point(63, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(34, 20);
            this.textBox1.TabIndex = 0;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox2.Location = new System.Drawing.Point(233, 12);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(34, 20);
            this.textBox2.TabIndex = 1;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // oneDie1
            // 
            this.oneDie1.BackColor = System.Drawing.SystemColors.Control;
            this.oneDie1.Image = ((System.Drawing.Image)(resources.GetObject("oneDie1.Image")));
            this.oneDie1.Location = new System.Drawing.Point(31, 55);
            this.oneDie1.Name = "oneDie1";
            this.oneDie1.Size = new System.Drawing.Size(34, 34);
            this.oneDie1.TabIndex = 2;
            this.oneDie1.UseVisualStyleBackColor = false;
            this.oneDie1.Click += new System.EventHandler(this.oneDie1_Click);
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // twoDie1
            // 
            this.twoDie1.BackColor = System.Drawing.SystemColors.Control;
            this.twoDie1.Image = ((System.Drawing.Image)(resources.GetObject("twoDie1.Image")));
            this.twoDie1.Location = new System.Drawing.Point(97, 55);
            this.twoDie1.Name = "twoDie1";
            this.twoDie1.Size = new System.Drawing.Size(34, 34);
            this.twoDie1.TabIndex = 3;
            this.twoDie1.UseVisualStyleBackColor = false;
            this.twoDie1.Click += new System.EventHandler(this.twoDie1_Click);
            // 
            // threeDie1
            // 
            this.threeDie1.BackColor = System.Drawing.SystemColors.Control;
            this.threeDie1.Image = ((System.Drawing.Image)(resources.GetObject("threeDie1.Image")));
            this.threeDie1.Location = new System.Drawing.Point(31, 111);
            this.threeDie1.Name = "threeDie1";
            this.threeDie1.Size = new System.Drawing.Size(34, 34);
            this.threeDie1.TabIndex = 4;
            this.threeDie1.UseVisualStyleBackColor = false;
            this.threeDie1.Click += new System.EventHandler(this.threeDie1_Click);
            // 
            // fourDie1
            // 
            this.fourDie1.BackColor = System.Drawing.SystemColors.Control;
            this.fourDie1.Image = ((System.Drawing.Image)(resources.GetObject("fourDie1.Image")));
            this.fourDie1.Location = new System.Drawing.Point(97, 111);
            this.fourDie1.Name = "fourDie1";
            this.fourDie1.Size = new System.Drawing.Size(34, 34);
            this.fourDie1.TabIndex = 5;
            this.fourDie1.UseVisualStyleBackColor = false;
            this.fourDie1.Click += new System.EventHandler(this.fourDie1_Click);
            // 
            // oneDie2
            // 
            this.oneDie2.BackColor = System.Drawing.SystemColors.Control;
            this.oneDie2.Image = ((System.Drawing.Image)(resources.GetObject("oneDie2.Image")));
            this.oneDie2.Location = new System.Drawing.Point(205, 55);
            this.oneDie2.Name = "oneDie2";
            this.oneDie2.Size = new System.Drawing.Size(34, 34);
            this.oneDie2.TabIndex = 6;
            this.oneDie2.UseVisualStyleBackColor = false;
            this.oneDie2.Click += new System.EventHandler(this.oneDie2_Click);
            // 
            // threeDie2
            // 
            this.threeDie2.BackColor = System.Drawing.SystemColors.Control;
            this.threeDie2.Image = ((System.Drawing.Image)(resources.GetObject("threeDie2.Image")));
            this.threeDie2.Location = new System.Drawing.Point(271, 55);
            this.threeDie2.Name = "threeDie2";
            this.threeDie2.Size = new System.Drawing.Size(34, 34);
            this.threeDie2.TabIndex = 7;
            this.threeDie2.UseVisualStyleBackColor = false;
            this.threeDie2.Click += new System.EventHandler(this.threeDie2_Click);
            // 
            // fourDie2
            // 
            this.fourDie2.BackColor = System.Drawing.SystemColors.Control;
            this.fourDie2.Image = ((System.Drawing.Image)(resources.GetObject("fourDie2.Image")));
            this.fourDie2.Location = new System.Drawing.Point(205, 111);
            this.fourDie2.Name = "fourDie2";
            this.fourDie2.Size = new System.Drawing.Size(34, 34);
            this.fourDie2.TabIndex = 8;
            this.fourDie2.UseVisualStyleBackColor = false;
            this.fourDie2.Click += new System.EventHandler(this.fourDie2_Click);
            // 
            // fiveDie2
            // 
            this.fiveDie2.BackColor = System.Drawing.SystemColors.Control;
            this.fiveDie2.Image = ((System.Drawing.Image)(resources.GetObject("fiveDie2.Image")));
            this.fiveDie2.Location = new System.Drawing.Point(271, 111);
            this.fiveDie2.Name = "fiveDie2";
            this.fiveDie2.Size = new System.Drawing.Size(34, 34);
            this.fiveDie2.TabIndex = 9;
            this.fiveDie2.UseVisualStyleBackColor = false;
            this.fiveDie2.Click += new System.EventHandler(this.fiveDie2_Click);
            // 
            // sixDie2
            // 
            this.sixDie2.BackColor = System.Drawing.SystemColors.Control;
            this.sixDie2.Image = ((System.Drawing.Image)(resources.GetObject("sixDie2.Image")));
            this.sixDie2.Location = new System.Drawing.Point(205, 168);
            this.sixDie2.Name = "sixDie2";
            this.sixDie2.Size = new System.Drawing.Size(34, 34);
            this.sixDie2.TabIndex = 10;
            this.sixDie2.UseVisualStyleBackColor = false;
            this.sixDie2.Click += new System.EventHandler(this.sixDie2_Click);
            // 
            // eightDie2
            // 
            this.eightDie2.BackColor = System.Drawing.SystemColors.Control;
            this.eightDie2.Image = ((System.Drawing.Image)(resources.GetObject("eightDie2.Image")));
            this.eightDie2.Location = new System.Drawing.Point(271, 168);
            this.eightDie2.Name = "eightDie2";
            this.eightDie2.Size = new System.Drawing.Size(34, 34);
            this.eightDie2.TabIndex = 11;
            this.eightDie2.UseVisualStyleBackColor = false;
            this.eightDie2.Click += new System.EventHandler(this.eightDie2_Click);
            // 
            // goButton
            // 
            this.goButton.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.goButton.Font = new System.Drawing.Font("Andy", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.goButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.goButton.Location = new System.Drawing.Point(97, 362);
            this.goButton.Name = "goButton";
            this.goButton.Size = new System.Drawing.Size(150, 40);
            this.goButton.TabIndex = 12;
            this.goButton.Text = "GO!";
            this.goButton.UseVisualStyleBackColor = false;
            this.goButton.Click += new System.EventHandler(this.goButton_Click_1);
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox3.Location = new System.Drawing.Point(155, 327);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(34, 20);
            this.textBox3.TabIndex = 13;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(83, 293);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(173, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Press \"GO!\" to compute dice score";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CadetBlue;
            this.ClientSize = new System.Drawing.Size(338, 414);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.goButton);
            this.Controls.Add(this.eightDie2);
            this.Controls.Add(this.sixDie2);
            this.Controls.Add(this.fiveDie2);
            this.Controls.Add(this.fourDie2);
            this.Controls.Add(this.threeDie2);
            this.Controls.Add(this.oneDie2);
            this.Controls.Add(this.fourDie1);
            this.Controls.Add(this.threeDie1);
            this.Controls.Add(this.twoDie1);
            this.Controls.Add(this.oneDie1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Weird Dice Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button oneDie1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button twoDie1;
        private System.Windows.Forms.Button threeDie1;
        private System.Windows.Forms.Button fourDie1;
        private System.Windows.Forms.Button oneDie2;
        private System.Windows.Forms.Button threeDie2;
        private System.Windows.Forms.Button fourDie2;
        private System.Windows.Forms.Button fiveDie2;
        private System.Windows.Forms.Button sixDie2;
        private System.Windows.Forms.Button eightDie2;
        private System.Windows.Forms.Button goButton;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label1;


    }
}

